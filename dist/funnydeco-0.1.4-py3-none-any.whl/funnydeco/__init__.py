from funnydeco.core import *

name = 'funnydeco'
